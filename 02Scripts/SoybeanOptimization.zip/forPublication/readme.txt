Iowa State Univeristy - Department of Agronomy
May 29, 2014

the folder contains the R optimization code used in the manuscript
"A methodlogy and an optimization tool to calibrate phenology of short-days species 
included in the APSIM-PLANT model: application to soybean"
published in Environmental Modelling & Software (2014)
by S.V. Archontoulis, F.E. Miguez and K.J Moore
http://dx.doi.org/10.1016/j.envsoft.2014.04.009


Explanation of files:
1. phenologyAPSIM.R is an R file that contains the functions needed to simulate phenology.
   This file can be used by itself if the objective is to understand how phenology is simulated.
   It contains auxiliary functions that calculate photoperiod and growing degree days.
2. optimPhenoFunc.R is an R file that contains the functions needed to perform optimization.
   If a user wants to use these functions directly he/she would probably be interested in using mcmc_soyp only.
   For this function to work the previous files is needed (phenologyAPSIM.R).
3. optimPhenoVar.R is an R script that contains an example application of the code from 1. and 2. Here we only use
   data from Arkansas. Results from this mcmc approach always need to be examined and results checked. 
   It is possible to get better results by modifying certain parameters such as scale or tpar. 
   At least run 3 chains and apply diagnostics (coda package).

The optimization code is slow, depending on the number of iterations 
and CPU and number of treatments, it can take up to 1 day approximately. 


for questions on the
optimization code and R stuff: femiguez@iastsate.edu (Fernando)
phenology equations and parameters: sarchont@iastate.edu (Sotirios)




 
